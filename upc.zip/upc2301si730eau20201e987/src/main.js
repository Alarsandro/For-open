import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import router from "./router/index.js";

// PrimeVue
import PrimeVue from "primevue/config";
import 'primevue/resources/themes/soho-light/theme.css';
import 'primevue/resources/primevue.min.css';
import 'primeicons/primeicons.css';
import 'primeflex/primeflex.css';


// Material design
import Toolbar from "primevue/toolbar";
import Card from "primevue/card";
import Button from "primevue/button";
import Sidebar from "primevue/sidebar";
import DataTable from "primevue/datatable";
import Column from "primevue/column";
import Paginator from 'primevue/paginator';
import InputText from "primevue/inputtext";

createApp(App)
    .use(router)
    .use(PrimeVue, { ripple: true })
    .component('pv-sidebar', Sidebar)
    .component('pv-toolbar', Toolbar)
    .component('pv-button', Button)
    .component('pv-card', Card)
    .component('pv-data-table', DataTable)
    .component('pv-column', Column)
    .component('pv-paginator', Paginator)
    .component('pv-input-text', InputText)
    .mount('#app')
