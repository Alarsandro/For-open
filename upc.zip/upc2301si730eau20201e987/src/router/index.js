import { createRouter, createWebHistory } from "vue-router";

import NoFoundComponent from "../public/pages/no-found.component.vue";
import HomeComponent from "../public/pages/home.component.vue";
import healthChecksComponent from "../health-checks/pages/health-checks.component.vue";

const router = createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: '/analytics',
            component: healthChecksComponent,
            children: [
                { path: '', name: 'Analytics', component: healthChecksComponent },
                { path: 'health-checks', name: 'Health Check', component: healthChecksComponent }
            ]},
        { path: '/home', component: HomeComponent },
        { path: '', component: HomeComponent },
        { path: '/:pathMatch(.*)', component: NoFoundComponent }
    ]
});

export default router;
