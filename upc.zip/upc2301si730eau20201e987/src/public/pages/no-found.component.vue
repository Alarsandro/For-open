<template>
  <div class="error-container">
    <h1>
      <span class="error text-primary">ERROR 404:</span>
      <br>The page you are trying to reach doesn't exist!
      <br><span>Page not found: {{ getCurrentRoute() }}</span>
    </h1>
    <router-link to="/home">
      <pv-button>
        Go back to Home
      </pv-button>
    </router-link>
  </div>
</template>

<script>
export default {
  name: "no-found",
  methods: {
    getCurrentRoute() {
      return this.$route.path;
    }
  }
}
</script>

<style>
.error-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 24px;
}

h1 {
  font-size: 32px;
  line-height: 72px;
}
</style>