<template>
  <pv-data-table
      :paginator="true"
      :rows="5"
      paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
      :rowsPerPageOptions="[5, 10, 25]"
      currentPageReportTemplate="Showing {first} to {last} of {totalRecords} health checks"
      :value="healthChecks"
      :filters="filters"
      tableStyle="min-width: 50rem"
      removableSort>
    <template #header>
      <div class="flex flex-wrap align-items-center justify-content-between">
        <h1 class="text-xl text-900 font-bold">
          <i class="pi pi-chart-bar text-xl" />
          Health Checks
        </h1>
        <span class="p-input-icon-left">
          <i class="pi pi-search"></i>
          <pv-input-text
              v-model="filters['global'].value"
              placeholder="Filter search..."
          ></pv-input-text>
        </span>
      </div>
    </template>
    <pv-column field="id" header="Id" sortable></pv-column>
    <pv-column field="treadmillId" header="Treadmill Id" sortable></pv-column>
    <pv-column :field = "getSerialNumber" header="Serial Number" sortable></pv-column>
    <pv-column :field = "getCenterName" header="Center Name" sortable></pv-column>
    <pv-column :field = "getFormattedDate" header="Date" sortable></pv-column>
    <pv-column :field = "getFormattedTime" header="Time" sortable></pv-column>
    <pv-column field="volts" header="Volts" sortable></pv-column>
    <pv-column field="watts" header="Watts" sortable></pv-column>
    <pv-column field="hp" header="Hp" sortable></pv-column>
    <template #footer> In total there are {{ healthChecks ? healthChecks.length : 0 }} health checks. </template>
  </pv-data-table>
</template>

<script>
import { CentersService} from "../services/centers.service.js";
import { HealthChecksService } from "../services/health-checks.service.js";
import { TreadmillsService } from "../services/treadmills.service.js";
import { FilterMatchMode } from 'primevue/api';

export default {
  name: "health-checks",

  data(){
    return {
      healthChecks: [],
      treadmills: [],
      centers : [],
      centersService: new CentersService(),
      healthCheckService: new HealthChecksService(),
      treadmillService: new TreadmillsService(),
      filters: {},
    }
  },
  created(){
    this.centersService.getAll()
        .then(response => this.centers = response.data)
        .catch(error => {
          console.error('An error occurred with centers:', error);
        });
    this.healthCheckService.getAll()
        .then(response => this.healthChecks = response.data)
        .catch(error => {
          console.error('An error occurred with health checks:', error);
        });
    this.treadmillService.getAll()
        .then(response => this.treadmills = response.data)
        .catch(error => {
          console.error('An error occurred with treadmills:', error);
        });;
    this.initFilters();
  },
  methods: {
    getSerialNumber(record){
      const treadmill = this.treadmills.find(treadmill => treadmill.id === record.treadmillId);
      return treadmill ? treadmill.serialNumber : '-';
    },
    getCenterName(record) {
      // Get treadmill object
      const treadmill = this.treadmills.find(treadmill => treadmill.id === record.treadmillId);
      // Get center object
      const center = treadmill ? this.centers.find(center => center.id === treadmill.centerId) : null;
      return center ? center.name : '-';
    },
    getFormattedDate(record){
      return record.year + '-' + record.month + '-' + record.day;
    },
    getFormattedTime(record){
      return record.hour + ':' + record.minutes + ':' + record.seconds;
    },
    initFilters() {
      this.filters = {global: {value: null, matchMode: FilterMatchMode.CONTAINS}};
    }
  }
}
</script>

<style scoped>

</style>