import http from '../../shared/services/http-common.service.js';
export class TreadmillsService {
    getAll() {
        return http.get('/treadmills');
    }
}