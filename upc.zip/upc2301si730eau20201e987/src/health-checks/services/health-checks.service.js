import http from '../../shared/services/http-common.service.js';
export class HealthChecksService {
    getAll() {
        return http.get('/health-checks');
    }
}