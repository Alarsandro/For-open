import http from '../../shared/services/http-common.service.js';
export class CentersService {
    getAll() {
        return http.get('/centers');
    }
}