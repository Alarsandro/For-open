<template>
  <pv-toolbar>
    <template #start>
      <router-link to="/home" class="title">
        <h3 class="text-primary">
          <span>
            <img src="/run-svgrepo-com.svg" alt="TechnoGym Icon" class="w-1rem">
          </span>
          TechnoGym TechnoRun Analytics
        </h3>
      </router-link>
    </template>
    <template #end>
      <router-link to="/home">
        <pv-button class="mr-2" label="Home" icon="pi pi-home" />
      </router-link>
      <router-link to="/analytics/health-checks">
        <pv-button class="mr-2" label="Health Checks" icon="pi pi-chart-bar" />
      </router-link>
    </template>
  </pv-toolbar>
  <router-view></router-view>
</template>


export default {
  name: "app"
}

<style scoped>
.title {
  text-decoration: none;
  color: inherit;
}
</style>
